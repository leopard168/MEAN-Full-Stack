
var express = require('express');
var bodyParser=require('body-parser');

var app=express();
app.use(bodyParser.urlencoded({extended:true}));

app.post('/urlencode',function(req,res){
    console.log(req.body);
    res.send("success");
});


// start server
var server = app.listen(3000, function () {
    console.log('Server listening at http://' + server.address().address + ':' + server.address().port);
});






